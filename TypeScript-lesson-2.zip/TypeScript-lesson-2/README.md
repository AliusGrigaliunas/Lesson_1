# TypeScript - Tipų aprašymas

1. Failus skaitykite ir atlikite tokia tvarka:
  * TS-2-typed-functions
  * TS-2-typed-objects
  * TS-2-typed-arrays
  * TS-2-exercises

  Atliekant kiekvieno aplanko/temos užduotis reikės:
   * parsisiųsti bibliotekas.
   * įjungti kompiliavimą
   * Sukurti html failą, kuriame bus įtraukiamas sukompiliuotas kodas

2. Atlikus visus darbus, supaprastinkite konfiguraciją:
  * Aprašykite kompiliavimo taisykles faile './tsconfig.base.json'.
  * Kiekvieno aplanko tsconfig.json faile pašalinkite taisyklių rinkinius ir įtraukite bendrą './tsconfig.base.json' failą:
    Kaip tai padaryti rasite čia:
    https://www.typescriptlang.org/tsconfig#extends
